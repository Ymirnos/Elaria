Oyunun yazı tipi: Monocraft (IdreesInc/Monocraft, https://github.com/IdreesInc/Monocraft)
Lisans: SIL Open Font License 1.1 — oyunu dağıtırsan lisans metnini (OFL.txt, Monocraft deposunda) yanına koy.

font.fnt + font.png, Tools/make_font.py ile Monocraft'tan üretilmiş BMFont (piksel atlası):
    python Tools/make_font.py %LOCALAPPDATA%/Microsoft/Windows/Fonts/Monocraft.ttc 0 Assets/Fonts

Neden .ttf değil: Monocraft'ın pikselleri em başına 9 piksele oturur, raylib ise TTF'yi başka bir yüksekliğe
göre ölçekler ve harfler bulanıklaşır. Atlasta her harf tam pikselinde durur. Türkçe harflerin hepsi var.

Başka bir font denemek: aynı adla font.fnt/font.png koy (BMFont metin biçimi) ya da ikisini silip font.ttf koy
(boyutu Core/Settings.cs -> CustomFontSize). Hiçbiri yoksa raylib'in dahili fontu kullanılır ve Türkçe harfler
en yakın ASCII harfe çevrilir (ğ -> g).
